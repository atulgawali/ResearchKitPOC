//
//  InnerField.m
//
//  Created by Atul Gawali on 22/12/16
//  Copyright (c) 2016 __MyCompanyName__. All rights reserved.
//

#import "InnerField.h"


NSString *const kInnerFieldPatientLastName = @"PatientLastName";
NSString *const kInnerFieldSocialSecurityNumber = @"SocialSecurityNumber";
NSString *const kInnerFieldTitle = @"title";
NSString *const kInnerFieldPatientFirstName = @"PatientFirstName";
NSString *const kInnerFieldPatientDateOfBirth = @"PatientDateOfBirth";
NSString *const kInnerFieldPatientGender = @"PatientGender";
NSString *const kInnerFieldSpecialREquirement = @"SpecialREquirement";
NSString *const kInnerFieldIcon = @"icon";
NSString *const kInnerFieldHideForDashboard = @"hideForDashboard";


@interface InnerField ()

- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict;

@end

@implementation InnerField

@synthesize patientLastName = _patientLastName;
@synthesize socialSecurityNumber = _socialSecurityNumber;
@synthesize title = _title;
@synthesize patientFirstName = _patientFirstName;
@synthesize patientDateOfBirth = _patientDateOfBirth;
@synthesize patientGender = _patientGender;
@synthesize specialREquirement = _specialREquirement;
@synthesize icon = _icon;
@synthesize hideForDashboard = _hideForDashboard;


+ (instancetype)modelObjectWithDictionary:(NSDictionary *)dict {
    return [[self alloc] initWithDictionary:dict];
}

- (instancetype)initWithDictionary:(NSDictionary *)dict {
    self = [super init];
    
    // This check serves to make sure that a non-NSDictionary object
    // passed into the model class doesn't break the parsing.
    if (self && [dict isKindOfClass:[NSDictionary class]]) {
            self.patientLastName = [self objectOrNilForKey:kInnerFieldPatientLastName fromDictionary:dict];
            self.socialSecurityNumber = [self objectOrNilForKey:kInnerFieldSocialSecurityNumber fromDictionary:dict];
            self.title = [self objectOrNilForKey:kInnerFieldTitle fromDictionary:dict];
            self.patientFirstName = [self objectOrNilForKey:kInnerFieldPatientFirstName fromDictionary:dict];
            self.patientDateOfBirth = [self objectOrNilForKey:kInnerFieldPatientDateOfBirth fromDictionary:dict];
            self.patientGender = [self objectOrNilForKey:kInnerFieldPatientGender fromDictionary:dict];
            self.specialREquirement = [self objectOrNilForKey:kInnerFieldSpecialREquirement fromDictionary:dict];
            self.icon = [self objectOrNilForKey:kInnerFieldIcon fromDictionary:dict];
            self.hideForDashboard = [self objectOrNilForKey:kInnerFieldHideForDashboard fromDictionary:dict];

    }
    
    return self;
    
}

- (NSDictionary *)dictionaryRepresentation {
    NSMutableDictionary *mutableDict = [NSMutableDictionary dictionary];
    [mutableDict setValue:self.patientLastName forKey:kInnerFieldPatientLastName];
    [mutableDict setValue:self.socialSecurityNumber forKey:kInnerFieldSocialSecurityNumber];
    [mutableDict setValue:self.title forKey:kInnerFieldTitle];
    [mutableDict setValue:self.patientFirstName forKey:kInnerFieldPatientFirstName];
    [mutableDict setValue:self.patientDateOfBirth forKey:kInnerFieldPatientDateOfBirth];
    [mutableDict setValue:self.patientGender forKey:kInnerFieldPatientGender];
    [mutableDict setValue:self.specialREquirement forKey:kInnerFieldSpecialREquirement];
    [mutableDict setValue:self.icon forKey:kInnerFieldIcon];
    [mutableDict setValue:self.hideForDashboard forKey:kInnerFieldHideForDashboard];

    return [NSDictionary dictionaryWithDictionary:mutableDict];
}

- (NSString *)description  {
    return [NSString stringWithFormat:@"%@", [self dictionaryRepresentation]];
}

#pragma mark - Helper Method
- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict {
    id object = [dict objectForKey:aKey];
    return [object isEqual:[NSNull null]] ? nil : object;
}


#pragma mark - NSCoding Methods

- (id)initWithCoder:(NSCoder *)aDecoder {
    self = [super init];

    self.patientLastName = [aDecoder decodeObjectForKey:kInnerFieldPatientLastName];
    self.socialSecurityNumber = [aDecoder decodeObjectForKey:kInnerFieldSocialSecurityNumber];
    self.title = [aDecoder decodeObjectForKey:kInnerFieldTitle];
    self.patientFirstName = [aDecoder decodeObjectForKey:kInnerFieldPatientFirstName];
    self.patientDateOfBirth = [aDecoder decodeObjectForKey:kInnerFieldPatientDateOfBirth];
    self.patientGender = [aDecoder decodeObjectForKey:kInnerFieldPatientGender];
    self.specialREquirement = [aDecoder decodeObjectForKey:kInnerFieldSpecialREquirement];
    self.icon = [aDecoder decodeObjectForKey:kInnerFieldIcon];
    self.hideForDashboard = [aDecoder decodeObjectForKey:kInnerFieldHideForDashboard];
    return self;
}

- (void)encodeWithCoder:(NSCoder *)aCoder
{

    [aCoder encodeObject:_patientLastName forKey:kInnerFieldPatientLastName];
    [aCoder encodeObject:_socialSecurityNumber forKey:kInnerFieldSocialSecurityNumber];
    [aCoder encodeObject:_title forKey:kInnerFieldTitle];
    [aCoder encodeObject:_patientFirstName forKey:kInnerFieldPatientFirstName];
    [aCoder encodeObject:_patientDateOfBirth forKey:kInnerFieldPatientDateOfBirth];
    [aCoder encodeObject:_patientGender forKey:kInnerFieldPatientGender];
    [aCoder encodeObject:_specialREquirement forKey:kInnerFieldSpecialREquirement];
    [aCoder encodeObject:_icon forKey:kInnerFieldIcon];
    [aCoder encodeObject:_hideForDashboard forKey:kInnerFieldHideForDashboard];
}

- (id)copyWithZone:(NSZone *)zone {
    InnerField *copy = [[InnerField alloc] init];
    
    
    
    if (copy) {

        copy.patientLastName = [self.patientLastName copyWithZone:zone];
        copy.socialSecurityNumber = [self.socialSecurityNumber copyWithZone:zone];
        copy.title = [self.title copyWithZone:zone];
        copy.patientFirstName = [self.patientFirstName copyWithZone:zone];
        copy.patientDateOfBirth = [self.patientDateOfBirth copyWithZone:zone];
        copy.patientGender = [self.patientGender copyWithZone:zone];
        copy.specialREquirement = [self.specialREquirement copyWithZone:zone];
        copy.icon = [self.icon copyWithZone:zone];
        copy.hideForDashboard = [self.hideForDashboard copyWithZone:zone];
    }
    
    return copy;
}


@end
