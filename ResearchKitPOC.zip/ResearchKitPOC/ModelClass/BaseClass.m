//
//  BaseClass.m
//
//  Created by Atul Gawali on 22/12/16
//  Copyright (c) 2016 __MyCompanyName__. All rights reserved.
//

#import "BaseClass.h"
#import "FormContainer.h"


NSString *const kBaseClassFormContainer = @"FormContainer";


@interface BaseClass ()

- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict;

@end

@implementation BaseClass

@synthesize formContainer = _formContainer;


+ (instancetype)modelObjectWithDictionary:(NSDictionary *)dict {
    return [[self alloc] initWithDictionary:dict];
}

- (instancetype)initWithDictionary:(NSDictionary *)dict {
    self = [super init];
    
    // This check serves to make sure that a non-NSDictionary object
    // passed into the model class doesn't break the parsing.
    if (self && [dict isKindOfClass:[NSDictionary class]]) {
    NSObject *receivedFormContainer = [dict objectForKey:kBaseClassFormContainer];
    NSMutableArray *parsedFormContainer = [NSMutableArray array];
    
    if ([receivedFormContainer isKindOfClass:[NSArray class]]) {
        for (NSDictionary *item in (NSArray *)receivedFormContainer) {
            if ([item isKindOfClass:[NSDictionary class]]) {
                [parsedFormContainer addObject:[FormContainer modelObjectWithDictionary:item]];
            }
       }
    } else if ([receivedFormContainer isKindOfClass:[NSDictionary class]]) {
       [parsedFormContainer addObject:[FormContainer modelObjectWithDictionary:(NSDictionary *)receivedFormContainer]];
    }

    self.formContainer = [NSArray arrayWithArray:parsedFormContainer];

    }
    
    return self;
    
}

- (NSDictionary *)dictionaryRepresentation {
    NSMutableDictionary *mutableDict = [NSMutableDictionary dictionary];
    NSMutableArray *tempArrayForFormContainer = [NSMutableArray array];
    
    for (NSObject *subArrayObject in self.formContainer) {
        if ([subArrayObject respondsToSelector:@selector(dictionaryRepresentation)]) {
            // This class is a model object
            [tempArrayForFormContainer addObject:[subArrayObject performSelector:@selector(dictionaryRepresentation)]];
        } else {
            // Generic object
            [tempArrayForFormContainer addObject:subArrayObject];
        }
    }
    [mutableDict setValue:[NSArray arrayWithArray:tempArrayForFormContainer] forKey:kBaseClassFormContainer];

    return [NSDictionary dictionaryWithDictionary:mutableDict];
}

- (NSString *)description  {
    return [NSString stringWithFormat:@"%@", [self dictionaryRepresentation]];
}

#pragma mark - Helper Method
- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict {
    id object = [dict objectForKey:aKey];
    return [object isEqual:[NSNull null]] ? nil : object;
}


#pragma mark - NSCoding Methods

- (id)initWithCoder:(NSCoder *)aDecoder {
    self = [super init];

    self.formContainer = [aDecoder decodeObjectForKey:kBaseClassFormContainer];
    return self;
}

- (void)encodeWithCoder:(NSCoder *)aCoder
{

    [aCoder encodeObject:_formContainer forKey:kBaseClassFormContainer];
}

- (id)copyWithZone:(NSZone *)zone {
    BaseClass *copy = [[BaseClass alloc] init];
    
    
    
    if (copy) {

        copy.formContainer = [self.formContainer copyWithZone:zone];
    }
    
    return copy;
}


@end
