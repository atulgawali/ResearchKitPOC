//
//  InnerField.h
//
//  Created by Atul Gawali on 22/12/16
//  Copyright (c) 2016 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>



@interface InnerField : NSObject <NSCoding, NSCopying>

@property (nonatomic, strong) NSString *patientLastName;
@property (nonatomic, strong) NSString *socialSecurityNumber;
@property (nonatomic, strong) NSString *title;
@property (nonatomic, strong) NSString *patientFirstName;
@property (nonatomic, strong) NSString *patientDateOfBirth;
@property (nonatomic, strong) NSString *patientGender;
@property (nonatomic, strong) NSString *specialREquirement;
@property (nonatomic, strong) NSString *icon;
@property (nonatomic, strong) NSString *hideForDashboard;

+ (instancetype)modelObjectWithDictionary:(NSDictionary *)dict;
- (instancetype)initWithDictionary:(NSDictionary *)dict;
- (NSDictionary *)dictionaryRepresentation;

@end
