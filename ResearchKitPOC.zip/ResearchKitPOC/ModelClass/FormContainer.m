//
//  FormContainer.m
//
//  Created by Atul Gawali on 22/12/16
//  Copyright (c) 2016 __MyCompanyName__. All rights reserved.
//

#import "FormContainer.h"
#import "InnerField.h"


NSString *const kFormContainerFieldSection = @"FieldSection";
NSString *const kFormContainerInnerField = @"InnerField";


@interface FormContainer ()

- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict;

@end

@implementation FormContainer

@synthesize fieldSection = _fieldSection;
@synthesize innerField = _innerField;


+ (instancetype)modelObjectWithDictionary:(NSDictionary *)dict {
    return [[self alloc] initWithDictionary:dict];
}

- (instancetype)initWithDictionary:(NSDictionary *)dict {
    self = [super init];
    
    // This check serves to make sure that a non-NSDictionary object
    // passed into the model class doesn't break the parsing.
    if (self && [dict isKindOfClass:[NSDictionary class]]) {
            self.fieldSection = [self objectOrNilForKey:kFormContainerFieldSection fromDictionary:dict];
    NSObject *receivedInnerField = [dict objectForKey:kFormContainerInnerField];
    NSMutableArray *parsedInnerField = [NSMutableArray array];
    
    if ([receivedInnerField isKindOfClass:[NSArray class]]) {
        for (NSDictionary *item in (NSArray *)receivedInnerField) {
            if ([item isKindOfClass:[NSDictionary class]]) {
                [parsedInnerField addObject:[InnerField modelObjectWithDictionary:item]];
            }
       }
    } else if ([receivedInnerField isKindOfClass:[NSDictionary class]]) {
       [parsedInnerField addObject:[InnerField modelObjectWithDictionary:(NSDictionary *)receivedInnerField]];
    }

    self.innerField = [NSArray arrayWithArray:parsedInnerField];

    }
    
    return self;
    
}

- (NSDictionary *)dictionaryRepresentation {
    NSMutableDictionary *mutableDict = [NSMutableDictionary dictionary];
    [mutableDict setValue:self.fieldSection forKey:kFormContainerFieldSection];
    NSMutableArray *tempArrayForInnerField = [NSMutableArray array];
    
    for (NSObject *subArrayObject in self.innerField) {
        if ([subArrayObject respondsToSelector:@selector(dictionaryRepresentation)]) {
            // This class is a model object
            [tempArrayForInnerField addObject:[subArrayObject performSelector:@selector(dictionaryRepresentation)]];
        } else {
            // Generic object
            [tempArrayForInnerField addObject:subArrayObject];
        }
    }
    [mutableDict setValue:[NSArray arrayWithArray:tempArrayForInnerField] forKey:kFormContainerInnerField];

    return [NSDictionary dictionaryWithDictionary:mutableDict];
}

- (NSString *)description  {
    return [NSString stringWithFormat:@"%@", [self dictionaryRepresentation]];
}

#pragma mark - Helper Method
- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict {
    id object = [dict objectForKey:aKey];
    return [object isEqual:[NSNull null]] ? nil : object;
}


#pragma mark - NSCoding Methods

- (id)initWithCoder:(NSCoder *)aDecoder {
    self = [super init];

    self.fieldSection = [aDecoder decodeObjectForKey:kFormContainerFieldSection];
    self.innerField = [aDecoder decodeObjectForKey:kFormContainerInnerField];
    return self;
}

- (void)encodeWithCoder:(NSCoder *)aCoder
{

    [aCoder encodeObject:_fieldSection forKey:kFormContainerFieldSection];
    [aCoder encodeObject:_innerField forKey:kFormContainerInnerField];
}

- (id)copyWithZone:(NSZone *)zone {
    FormContainer *copy = [[FormContainer alloc] init];
    
    
    
    if (copy) {

        copy.fieldSection = [self.fieldSection copyWithZone:zone];
        copy.innerField = [self.innerField copyWithZone:zone];
    }
    
    return copy;
}


@end
