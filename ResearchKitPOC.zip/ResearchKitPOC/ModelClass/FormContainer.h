//
//  FormContainer.h
//
//  Created by Atul Gawali on 22/12/16
//  Copyright (c) 2016 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>



@interface FormContainer : NSObject <NSCoding, NSCopying>

@property (nonatomic, strong) NSString *fieldSection;
@property (nonatomic, strong) NSArray *innerField;

+ (instancetype)modelObjectWithDictionary:(NSDictionary *)dict;
- (instancetype)initWithDictionary:(NSDictionary *)dict;
- (NSDictionary *)dictionaryRepresentation;

@end
